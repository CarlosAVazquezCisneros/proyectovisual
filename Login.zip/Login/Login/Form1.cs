﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private bool ValidarSesion(string correo, string contraseña)
        {
            string connectionString = "Data Source=desktop-dpi6lmq\\sqlserver;Initial Catalog=tiendita;Integrated Security=True";

            string query = "SELECT COUNT(*) FROM usuarios WHERE Correo = @Correo AND Contraseña = @Contraseña";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Correo", correo);
                    command.Parameters.AddWithValue("@Contraseña", contraseña);

                    int count = (int)command.ExecuteScalar();

                    return count > 0; // Si el recuento es mayor que cero, el usuario está registrado y la sesión es válida
                }
            }
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string contraseña = txtContraseña.Text;

            // Llama a un método para validar la sesión
            if (ValidarSesion(usuario, contraseña))
            {
                MessageBox.Show("Inicio de sesión exitoso");
                // Realiza las acciones necesarias después de una sesión exitosa, como abrir el formulario principal
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos");
            }
        }
        }
}
